#include <stdio.h>

//Compiler version gcc  6.3.0

int main()
{
  float MT[3], PQ[10], AQ[6], SA[2], IG[3];
  float nMT, nPQ, nAQ, nSA, nIG;
  float sumMT, sumPQ, sumAQ, sumSA, sumIG;
  int k;
  printf("*********************\n");
  printf("FALL TERM\n");
  printf("*********************\n");
  printf("How many midterms have you taken?\n");
  scanf("%f", &nMT);
  printf("How many pop quizzes have you taken?\n");
  scanf("%f", &nPQ);
  printf("How many announced quizzes have you taken?\n");
  scanf("%f", &nAQ);
  printf("How many speaking assesments have you taken?\n");
  scanf("%f", &nSA);
  printf("How many instructor's grades have you been evaluated by?\n");
  scanf("%f", &nIG);
  printf("MIDTERMS\n");
  for (k = 0; k < nMT; k++)
  {
    scanf("%f",&MT[k]);
  }
  printf("POP-QUIZZES\n");
  for (k = 0; k < nPQ; k++)
  {
    scanf("%f",&PQ[k]);
  }
  printf("ANNOUNCED QUIZZES\n");
  for (k = 0; k < nAQ; k++)
  {
    scanf("%f",&AQ[k]);
  }
  printf("SPEAKING ASSESMENTS\n");
  for (k = 0; k < nSA; k++)
  {
    scanf("%f",&SA[k]);
  }
  printf("INSTRUCTOR'S GRADES\n");
  for (k = 0; k < nIG; k++)
  {
    scanf("%f",&IG[k]);
  }
  for (k = 0; k < nMT; k++)
  {
    sumMT += MT[k];
  }
  for (k = 0; k < nPQ; k++)
  {
    sumPQ += PQ[k];
  }
  for (k = 0; k < nAQ; k++)
  {
    sumAQ += AQ[k];
  }
  for (k = 0; k < nSA; k++)
  {
    sumSA += SA[k];
  }
  for (k = 0; k < nIG; k++)
  {
    sumIG += IG[k];
  }
  float FAA = 0, FAEPE;
  FAA = sumMT / nMT * 0.625 + ((sumIG + sumPQ)/(nIG + nPQ)) * 0.25 + sumAQ/nAQ * 0.125;
  printf("%f", FAA);
  FAEPE = (sumMT / nMT) * 5/9 + ((sumIG + sumPQ) / (nIG + nPQ)) * 2/9 + sumAQ / nAQ  * 1/9 + sumSA / nSA * 1/9;
  printf("% f", FAEPE);
  printf("*********************\n");
  printf("SPRING TERM\n");
  printf("*********************\n");
  printf("How many midterms have you taken?\n");
  scanf("%f", &nMT);
  printf("How many pop quizzes have you taken?\n");
  scanf("%f", &nPQ);
  printf("How many announced quizzes have you taken?\n");
  scanf("%f", &nAQ);
  printf("How many speaking assesments have you taken?\n");
  scanf("%f", &nSA);
  printf("How many instructor's grades have you been evaluated by?\n");
  scanf("%f", &nIG);
  printf("MIDTERMS\n");
  for (k = 0; k < nMT; k++)
  {
    scanf("%f",&MT[k]);
  }
  printf("POP-QUIZZES\n");
  for (k = 0; k < nPQ; k++)
  {
    scanf("%f",&PQ[k]);
  }
  printf("ANNOUNCED QUIZZES\n");
  for (k = 0; k < nAQ; k++)
  {
    scanf("%f",&AQ[k]);
  }
  printf("SPEAKING ASSESMENTS\n");
  for (k = 0; k < nSA; k++)
  {
    scanf("%f",&SA[k]);
  }
  printf("INSTRUCTOR'S GRADES\n");
  for (k = 0; k < nIG; k++)
  {
    scanf("%f",&IG[k]);
  }
  sumMT = 0;
  sumPQ = 0;
  sumAQ = 0;
  sumSA = 0;
  sumIG = 0;
  for (k = 0; k < nMT; k++)
  {
    sumMT += MT[k];
  }
  for (k = 0; k < nPQ; k++)
  {
    sumPQ += PQ[k];
  }
  for (k = 0; k < nAQ; k++)
  {
    sumAQ += AQ[k];
  }
  for (k = 0; k < nSA; k++)
  {
    sumSA += SA[k];
  }
  for (k = 0; k < nIG; k++)
  {
    sumIG += IG[k];
  }
  float SAA = 0, SAEPE;
  SAA = sumMT / nMT * 0.625 + ((sumIG + sumPQ)/(nIG + nPQ)) * 0.25 + sumAQ/nAQ * 0.125;
  printf("%f", SAA);
  SAEPE = (sumMT / nMT) * 7/11 + ((sumIG + sumPQ) / (nIG + nPQ)) * 2/11 + sumAQ / nAQ  * 1/11 + sumSA / nSA * 1/11;
  printf("% f", SAEPE);
  float TA;
  TA = FAEPE * 9/20 + SAEPE * 11/20;
}